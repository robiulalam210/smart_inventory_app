import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../configs/app_constants.dart';
import '../database/login.dart';
import '../offline/offline_gateway.dart';
import '../offline/connectivity_monitor.dart';
import '../offline/uuid_v4.dart';

Future<Map<String, dynamic>> patchResponse({
  required String url,
  required Map<String, dynamic> payload,
  bool retried = false,
}) async {
  Uri uriUrl = Uri.parse(url);
  // Offline এ edit/delete করা যায় না (conflict ও হিসাবের গরমিল এড়াতে)
  final gateway = OfflineGateway.instance;
  if (gateway.isOffline) return gateway.offlineBlocked();
  final opId = uuidV4();
  final token = await LocalDB.getLoginInfo();
  logger.i("patchResponse uriUrl: $uriUrl");
  logger.i("payload: $payload");

  final Map<String, String> header = {
    "Content-Type": "application/json",
    'Authorization': 'Bearer ${token?['token']}',
  };
  header.addAll(await gateway.extraHeaders(opId: opId));

  try {
    final response = await http
        .patch(uriUrl, body: jsonEncode(payload), headers: header)
        .timeout(const Duration(seconds: 60));

    logger.i("patchResponse statusCode: ${response.statusCode}");
    logger.i("patchResponse body: ${response.body}");

    // Token expire (401) → নতুন token নিয়ে একবার আবার চেষ্টা (mobile + desktop)
    if (response.statusCode == 401 && !retried && await SessionKeeper.renew()) {
      return patchResponse(url: url, payload: payload, retried: true);
    }

    final Map<String, dynamic> responseData = jsonDecode(response.body);

    // Handle both response formats
    if (response.statusCode == 200 || response.statusCode == 201) {
      // Check if it's a raw Django response (has 'id' field but no 'success' field)
      if (responseData.containsKey('id') && !responseData.containsKey('success')) {
        // Convert raw Django response to structured format
        return {
          "success": true,
          "message": "Updated successfully",
          "data": responseData
        };
      }
      // It's already a structured response
      return responseData;
    } else {
      // Error response
      return {
        "success": false,
        "message": responseData['message'] ?? "Update failed",
        "data": null
      };
    }

  } on TimeoutException {
    return {
      "success": false,
      "title": "Timeout",
      "message": "The request timed out. Please try again later.",
      "data": null
    };
  } on SocketException {
    if (gateway.enabled) ConnectivityMonitor.instance.markOffline();
    return {
      "success": false,
      "title": "Connection Failed",
      "message": "Unable to connect to the server. Please check your network connection and try again.",
      "data": null
    };
  } catch (e) {
    return {
      "success": false,
      "title": "Failed",
      "message": "An error occurred while communicating with the server: $e",
      "data": null
    };
  }
}