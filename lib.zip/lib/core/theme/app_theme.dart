import 'package:flutter/material.dart';

import '../configs/app_colors.dart';
import '../configs/app_text.dart';

/// অ্যাপের পুরো রঙ/কম্পোনেন্ট থিম (desktop + mobile একই)।
///
/// নীতি:
///  * একটাই ব্র্যান্ড রঙ (primary) — তার উপরের লেখা সবসময় [AppColors.onColor] দিয়ে contrast-নিরাপদ
///  * নিরপেক্ষ রঙ slate স্কেলের (খাঁটি কালো/সাদা নয়) — চোখে আরামদায়ক
///  * semantic রঙ: success সবুজ, danger লাল, warning অ্যাম্বার, info নীল
class AppTheme {
  static ThemeData light(BuildContext context) {
    final primary = AppColors.primaryColor(context);
    final onPrimary = AppColors.onColor(primary);

    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: Brightness.light,
    ).copyWith(
      primary: primary,
      onPrimary: onPrimary,
      secondary: AppColors.secondary(context),
      error: AppColors.danger,
      surface: Colors.white,
      onSurface: AppColors.lightText,
      outline: AppColors.border,
      outlineVariant: AppColors.borderLight,
    );

    return _base(
      context: context,
      brightness: Brightness.light,
      scheme: scheme,
      primary: primary,
      onPrimary: onPrimary,
      scaffold: AppColors.lightBg,
      surface: Colors.white,
      text: AppColors.lightText,
      border: AppColors.borderLight,
      tooltipBg: const Color(0xFF0F172A),
    );
  }

  static ThemeData dark(BuildContext context) {
    final primary = AppColors.primaryColor(context);
    final onPrimary = AppColors.onColor(primary);

    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: Brightness.dark,
    ).copyWith(
      primary: primary,
      onPrimary: onPrimary,
      secondary: AppColors.secondary(context),
      error: const Color(0xFFF87171),
      surface: AppColors.darkBgBottomNav,
      onSurface: AppColors.darkText,
      outline: const Color(0xFF34425F),
      outlineVariant: const Color(0xFF243049),
    );

    return _base(
      context: context,
      brightness: Brightness.dark,
      scheme: scheme,
      primary: primary,
      onPrimary: onPrimary,
      scaffold: AppColors.darkBg,
      surface: AppColors.darkBgBottomNav,
      text: AppColors.darkText,
      border: const Color(0xFF243049),
      tooltipBg: const Color(0xFF1C2640),
    );
  }

  static ThemeData _base({
    required BuildContext context,
    required Brightness brightness,
    required ColorScheme scheme,
    required Color primary,
    required Color onPrimary,
    required Color scaffold,
    required Color surface,
    required Color text,
    required Color border,
    required Color tooltipBg,
  }) {
    final isDark = brightness == Brightness.dark;
    final radius = BorderRadius.circular(10); // ওয়েবের --r-md
    // ওয়েবের .btn-ghost: surface + নিরপেক্ষ রেখা + ink-2 লেখা
    final ghostLine = isDark ? const Color(0xFF34425F) : const Color(0xFFCBD5E1);
    final ghostInk = isDark ? const Color(0xFFC4CDE1) : const Color(0xFF334155);
    const btnText = TextStyle(fontWeight: FontWeight.w600, fontSize: 14);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      scaffoldBackgroundColor: scaffold,
      canvasColor: surface,
      cardColor: surface,
      dividerColor: border,
      fontFamily: AppTextStyle.fontFamily,
      fontFamilyFallback: AppTextStyle.fontFallback,
      colorScheme: scheme,
      textTheme: TextTheme(
        displayLarge: AppTextStyle.titleBold(context),
        titleMedium: AppTextStyle.subtitle(context),
        bodyMedium: AppTextStyle.body(context),
        labelLarge: AppTextStyle.button(context),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        iconTheme: IconThemeData(color: text),
        titleTextStyle: TextStyle(
          color: text,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: border),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: border),
        ),
        titleTextStyle: TextStyle(color: text, fontSize: 17, fontWeight: FontWeight.w700),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: surface,
        showDragHandle: false,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: border),
        ),
      ),
      dividerTheme: DividerThemeData(color: border, thickness: 1, space: 1),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: onPrimary,
          minimumSize: const Size(0, 44),
          textStyle: btnText,
          shape: RoundedRectangleBorder(borderRadius: radius),
          shadowColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: isDark ? surface : Colors.white,
          foregroundColor: primary,
          minimumSize: const Size(0, 44),
          textStyle: btnText,
          shape: RoundedRectangleBorder(
            borderRadius: radius,
            side: BorderSide(color: primary),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: ghostInk,
          backgroundColor: surface,
          minimumSize: const Size(0, 44),
          textStyle: btnText,
          side: BorderSide(color: ghostLine),
          shape: RoundedRectangleBorder(borderRadius: radius),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primary,
          textStyle: btnText,
          shape: RoundedRectangleBorder(borderRadius: radius),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: onPrimary,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(color: primary),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStateProperty.all(
          isDark ? const Color(0xFF475569) : const Color(0xFFCBD5E1),
        ),
        radius: const Radius.circular(8),
        thickness: WidgetStateProperty.all(6),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: tooltipBg,
          borderRadius: BorderRadius.circular(6),
        ),
        textStyle: const TextStyle(color: Colors.white, fontSize: 12),
        waitDuration: const Duration(milliseconds: 400),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: tooltipBg,
        contentTextStyle: const TextStyle(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      dataTableTheme: DataTableThemeData(
        headingRowColor: WidgetStateProperty.all(
          isDark ? const Color(0xFF172034) : const Color(0xFFFAFBFD),
        ),
        headingTextStyle: TextStyle(
          color: isDark ? const Color(0xFF8E9AB2) : const Color(0xFF64748B),
          fontWeight: FontWeight.w600,
          fontSize: 12.5,
        ),
        dividerThickness: 0.6,
        // সব desktop টেবিলের জন্য একই নিয়ম:
        // horizontalMargin 0 — প্রায় সব টেবিল column width = মোট প্রস্থ /
        // column সংখ্যা ধরে হিসাব করে। default 24px margin দুই পাশে যোগ
        // হয়ে টেবিল পর্দার চেয়ে ৪৮px চওড়া হয়ে যেত — ফলে অকারণ horizontal
        // scrollbar আসত আর প্রথম column ("Receipt No") কেটে যেত
        // (row height theme এ দেওয়া হয়নি — কিছু টেবিল নিজেই
        // dataRowMaxHeight ছোট দেয়, theme এর min বড় হলে assertion ভাঙত)
        horizontalMargin: 0,
        dataTextStyle: TextStyle(color: text, fontSize: 13),
        // mouse নিলে row হালকা highlight — কোন row এ কাজ হচ্ছে বোঝা যায়
        dataRowColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.hovered)
              ? primary.withValues(alpha: 0.05)
              : null,
        ),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? primary : null,
        ),
        checkColor: WidgetStateProperty.all(onPrimary),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? onPrimary : null,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? primary : null,
        ),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? primary : null,
        ),
      ),
    );
  }
}
