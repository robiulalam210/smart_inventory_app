// lib/feature/report/presentation/screens/low_stock_screen.dart
import 'package:flutter/material.dart';
import 'package:meherinMart/core/widgets/app_data_table.dart';
import 'package:meherinMart/core/widgets/app_popover_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:iconsax/iconsax.dart';
import 'package:lottie/lottie.dart';
import 'package:printing/printing.dart';
import '../../../../profile/presentation/bloc/profile_bloc/profile_bloc.dart';
import '/core/configs/app_colors.dart';
import '/core/configs/app_images.dart';
import '/core/configs/app_text.dart';
import '/desktop/widgets/sidebar.dart';
import '/core/widgets/app_alert_dialog.dart';
import '/feature/report/presentation/bloc/low_stock_bloc/low_stock_bloc.dart';
import '/feature/report/presentation/shared/low_stock_screen/pdf/pdf.dart';

import '../../../../../core/configs/app_routes.dart';
import '../../../../../core/widgets/app_button.dart';
import '../../../../../responsive.dart';
import '../../../data/model/low_stock_model.dart';
import 'package:meherinMart/core/widgets/table_scroll_controllers.dart';

class LowStockScreen extends StatefulWidget {
  const LowStockScreen({super.key});

  @override
  State<LowStockScreen> createState() => _LowStockScreenState();
}

class _LowStockScreenState extends State<LowStockScreen> {
  @override
  void initState() {
    super.initState();
    _fetchLowStockReport();
  }

  void _fetchLowStockReport() {
    context.read<LowStockBloc>().add(FetchLowStockReport(context: context));
  }

  @override
  Widget build(BuildContext context) {
    final isBigScreen = Responsive.isDesktop(context) || Responsive.isMaxDesktop(context);

    return Container(
      color: AppColors.bottomNavBg(context),
      child: SafeArea(
        child: ResponsiveRow(
          children: [
            if (isBigScreen) _buildSidebar(),
            _buildContentArea(isBigScreen),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebar() => ResponsiveCol(
    xs: 0,
    sm: 1,
    md: 1,
    lg: 2,
    xl: 2,
    child: Container(color: Colors.white, child: const Sidebar()),
  );

  Widget _buildContentArea(bool isBigScreen) {
    return ResponsiveCol(
      xs: 12,
      lg: 10,
      child: RefreshIndicator(
        onRefresh: () async => _fetchLowStockReport(),
        child: Container(
          padding: AppTextStyle.getResponsivePaddingBody(context),
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 16),
              _buildAlertCards(),
              const SizedBox(height: 16),
              SizedBox(child: _buildLowStockTable()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Low Stock Alert",
              style: AppTextStyle.cardTitle(context).copyWith(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.danger,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "Monitor and manage products requiring restocking",
              style: GoogleFonts.inter(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        Row(
          children: [
            ElevatedButton.icon(
              onPressed: _fetchLowStockReport,
              icon: const Icon(Icons.refresh),
              label: const Text("Refresh"),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor(context),
                foregroundColor: Colors.white,
              ),
            ),
            const SizedBox(width: 10),
            BlocBuilder<LowStockBloc, LowStockState>(
              builder: (context, state) {
                if (state is LowStockSuccess) {
                  return ElevatedButton.icon(
                    onPressed: () => _showRestockAlert(context, state.response.report),
                    icon: const Icon(Icons.notification_important),
                    label: const Text("Restock Alert"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.warning,
                      foregroundColor: Colors.white,
                    ),
                  );
                }
                return const SizedBox();
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAlertCards() {
    return BlocBuilder<LowStockBloc, LowStockState>(
      builder: (context, state) {
        if (state is! LowStockSuccess) return const SizedBox();

        final summary = state.response.summary;

        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _buildAlertCard(
              "Total Low Stock Items",
              summary.totalLowStockItems.toString(),
              Icons.warning_amber,
              AppColors.warning,
              "Items below alert level",
            ),
            _buildAlertCard(
              "Critical Items",
              summary.criticalItems.toString(),
              Icons.dangerous,
              AppColors.danger,
              "Out of stock items",
            ),
            _buildAlertCard(
              "Alert Threshold",
              "Below ${summary.threshold}",
              Icons.settings,
              AppColors.info,
              "Stock alert level",
            ),
            _buildAlertCard(
              "Stock Health",
              "${((summary.totalLowStockItems - summary.criticalItems) / summary.totalLowStockItems * 100).toStringAsFixed(1)}%",
              Icons.health_and_safety,
              AppColors.success,
              "Items with some stock",
            ),
            AppButton(
                size: 100,
                name: "Pdf", onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Scaffold(
                    backgroundColor: AppColors.danger,
                    body: PdfPreview.builder(
                      useActions: true,
                      allowSharing: false,
                      canDebug: false,
                      canChangeOrientation: false,
                      canChangePageFormat: false,
                      dynamicLayout: true,
                      build: (format) => generateLowStockReportPdf(
                        state.response,
                          context.read<ProfileBloc>().permissionModel?.data?.companyInfo

                      ),
                      pdfPreviewPageDecoration:
                      BoxDecoration(color: AppColors.white),
                      actionBarTheme: PdfActionBarTheme(
                        backgroundColor: AppColors.primaryColor(context),
                        iconColor: Colors.white,
                        textStyle: const TextStyle(color: Colors.white),
                      ),
                      actions: [
                        IconButton(
                          onPressed: () => AppRoutes.pop(context),
                          icon: const Icon(Icons.cancel, color: AppColors.danger),
                        ),
                      ],
                      pagesBuilder: (context, pages) {
                        debugPrint('Rendering ${pages.length} pages');
                        return PageView.builder(
                          itemCount: pages.length,
                          scrollDirection: Axis.vertical,
                          itemBuilder: (context, index) {
                            final page = pages[index];
                            return Container(
                              color: Colors.grey,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(8.0),
                              child: Image(image: page.image, fit: BoxFit.contain),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              );

            }),
          ],
        );
      },
    );
  }

  Widget _buildAlertCard(String title, String value, IconData icon, Color color, String subtitle) {
    return Container(
      width: 200,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border.all(
            color:color.withValues(alpha: 0.5),width: 0.5
        ),
        color: AppColors.bottomNavBg(context),
        borderRadius: BorderRadius.circular(8),

      ),

      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLowStockTable() {
    return BlocBuilder<LowStockBloc, LowStockState>(
      builder: (context, state) {
        if (state is LowStockLoading) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text("Loading low stock report..."),
              ],
            ),
          );
        } else if (state is LowStockSuccess) {
          if (state.response.report.isEmpty) {
            return _buildEmptyState();
          }
          return LowStockTableCard(products: state.response.report);
        } else if (state is LowStockFailed) {
          return _buildErrorState(state.content);
        }
        return _buildEmptyState();
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(AppImages.noData, width: 200, height: 200),
          const SizedBox(height: 16),
          Text(
            "No Low Stock Items Found",
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.success,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Great job! All products are well-stocked",
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _fetchLowStockReport,
            child: const Text("Refresh"),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 60, color: AppColors.danger),
          const SizedBox(height: 16),
          Text(
            "Error Loading Low Stock Report",
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            error,
            style: const TextStyle(fontSize: 14, color: AppColors.danger),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _fetchLowStockReport,
            child: const Text("Retry"),
          ),
        ],
      ),
    );
  }

  void _showRestockAlert(BuildContext context, List<LowStockProduct> products) {
    final criticalItems = products.where((p) => p.totalStockQuantity == 0).length;
    final lowStockItems = products.where((p) => p.totalStockQuantity > 0 && p.totalStockQuantity <= p.alertQuantity).length;

    showAppPopover(
      context: context,
      builder: (context) => AppPopoverCard(
        title: const Row(
          children: [
            Icon(Icons.notification_important, color: AppColors.danger),
            SizedBox(width: 8),
            Text('Restock Alert Summary'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('You have ${products.length} items requiring attention:'),
            const SizedBox(height: 16),
            if (criticalItems > 0) _buildAlertItem('🚨 Critical Items (Out of Stock)', criticalItems, AppColors.danger),
            if (lowStockItems > 0) _buildAlertItem('⚠️ Low Stock Items', lowStockItems, AppColors.warning),
            const SizedBox(height: 16),
            const Text(
              'Consider creating purchase orders for these items to maintain optimal inventory levels.',
              style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Dismiss'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Navigate to bulk purchase screen
            },
            child: const Text('Bulk Restock'),
          ),
        ],
      ),
    );
  }

  Widget _buildAlertItem(String title, int count, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Row(
        children: [
          Text(
            title,
            style: TextStyle(color: color, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              count.toString(),
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

}

class LowStockTableCard extends StatelessWidget {
  final List<LowStockProduct> products;
  final VoidCallback? onProductTap;

  const LowStockTableCard({
    super.key,
    required this.products,
    this.onProductTap,
  });

  @override
  // Desktop টেবিল — AppDataTable
  Widget build(BuildContext context) {
    const columns = [
      AppTableColumn.center('SL', flex: 1, minWidth: 52),
      AppTableColumn('Product', flex: 4, minWidth: 170),
      AppTableColumn('Category', flex: 2, minWidth: 110),
      AppTableColumn.numeric('In Stock', flex: 1, minWidth: 90),
      AppTableColumn.numeric('Alert Level', flex: 1, minWidth: 100),
      AppTableColumn.numeric('Short By', flex: 1, minWidth: 90),
      AppTableColumn.center('Status', flex: 2, minWidth: 110),
      AppTableColumn.center('Actions', flex: 2, minWidth: 96),
    ];

    return AppDataTable(
      columns: columns,
      rowCount: products.length,
      onRowTap: onProductTap == null ? null : (_) => onProductTap!(),
      cellBuilder: (context, row, col) {
        final p = products[row];
        switch (col) {
          case 0:
            return AppTableText('${row + 1}',
                align: AppCellAlign.center, muted: true);
          case 1:
            return AppTableText(p.productName, bold: true, subtitle: p.brand);
          case 2:
            return AppTableText(p.category, muted: true);
          case 3:
            return AppTableText('${p.totalStockQuantity}',
                align: AppCellAlign.end, bold: true, color: p.statusColor);
          case 4:
            return AppTableText('${p.alertQuantity}',
                align: AppCellAlign.end, muted: true);
          case 5:
            final short = p.alertQuantity - p.totalStockQuantity;
            return AppTableText(short > 0 ? '$short' : '-',
                align: AppCellAlign.end,
                color: short > 0 ? AppColors.danger : null);
          case 6:
            return AppStatusPill(p.stockStatus, color: p.statusColor);
          default:
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppTableAction(
                  icon: Icons.visibility_outlined,
                  tooltip: 'Product details',
                  color: AppColors.info,
                  onPressed: () => _showProductDetails(context, p),
                ),
                AppTableAction(
                  icon: Icons.add_shopping_cart_rounded,
                  tooltip: 'Create purchase',
                  color: p.totalStockQuantity == 0
                      ? AppColors.danger
                      : AppColors.warning,
                  onPressed: () => _navigateToRestock(context, p),
                ),
              ],
            );
        }
      },
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required Color color,
    required String tooltip,
    required VoidCallback onPressed,
  }) {
    return IconButton(
      onPressed: onPressed,
      icon: Icon(icon, size: 16, color: color),
      tooltip: tooltip,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 25, minHeight: 25),
    );
  }

  void _showProductDetails(BuildContext context, LowStockProduct product) {
    showAppPopover(
      context: context,
      builder: (context) {
        return AppPopoverShell(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.40,
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.productName,
                  style: AppTextStyle.cardLevelHead(context).copyWith(color: AppColors.danger),
                ),
                const SizedBox(height: 16),
                _buildDetailRow('Category:', product.category),
                _buildDetailRow('Brand:', product.brand),
                _buildDetailRow('Selling Price:', product.sellingPrice.toStringAsFixed(2)),
                _buildDetailRow('Current Stock:', product.totalStockQuantity.toString()),
                _buildDetailRow('Alert Level:', product.alertQuantity.toString()),
                _buildDetailRow('Total Sold:', product.totalSoldQuantity.toString()),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: product.statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: product.statusColor),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.warning, color: product.statusColor, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          product.totalStockQuantity == 0
                              ? '🚨 OUT OF STOCK - Immediate restock required!'
                              : '⚠️ LOW STOCK - ${product.belowAlertLevel} units below alert level',
                          style: TextStyle(
                            color: product.statusColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerRight,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Close'),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          _navigateToRestock(context, product);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.warning,
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Create Purchase Order'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToRestock(BuildContext context, LowStockProduct product) {
    appAlertDialog(
      context,
      "Navigate to purchase screen to restock ${product.productName}?",
      title: "Restock Product",
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Cancel"),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            // Add your navigation logic here
            // context.read<DashboardBloc>().add(ChangeDashboardScreen(index: /* purchase screen index */));
          },
          child: const Text("Go to Purchase"),
        ),
      ],
    );
  }
}