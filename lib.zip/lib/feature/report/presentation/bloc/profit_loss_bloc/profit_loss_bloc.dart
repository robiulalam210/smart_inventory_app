// lib/feature/report/presentation/bloc/profit_loss_bloc/profit_loss_bloc.dart
import '/core/core.dart';
import '../../../data/model/profit_loss_report_model.dart';

part 'profit_loss_event.dart';
part 'profit_loss_state.dart';

class ProfitLossBloc extends Bloc<ProfitLossEvent, ProfitLossState> {
  DateTime? fromDate;
  DateTime? toDate;

  ProfitLossBloc() : super(ProfitLossInitial()) {
    on<FetchProfitLossReport>((event, emit) async {
      emit(ProfitLossLoading());

      try {
        // Update filter values
        fromDate = event.from ?? fromDate;
        toDate = event.to ?? toDate;

        // Build query parameters
        // page_size: backend প্রতি page এ ১০০টা দেয় — আগে শুধু প্রথম page আসত, তাই table অসম্পূর্ণ থাকত
        final Map<String, String> queryParams = {'page_size': '1000'};

        if (event.from != null && event.to != null) {
          queryParams['start'] = event.from!.toIso8601String().split('T')[0];
          queryParams['end'] = event.to!.toIso8601String().split('T')[0];
        }

        // Build filter string
        String filter = '';
        if (queryParams.isNotEmpty) {
          filter = '?${Uri(queryParameters: queryParams).query}';
        }


        final responseString = await getResponse(
          url: AppUrls.profitLoss + filter,
          context: event.context,
        );

        final Map<String, dynamic> res = jsonDecode(responseString);

        // Check if the response indicates success
        if (res['status'] == true) {
          final data = res['data'];

          try {
            final profitLossResponse = ProfitLossResponse.fromJson(data as Map<String, dynamic>);

            emit(ProfitLossSuccess(response: profitLossResponse));
          } catch (parseError) {
            emit(ProfitLossFailed(
              title: "Parsing Error",
              content: "Failed to parse profit & loss report data: $parseError",
            ));
          }
        } else {
          emit(ProfitLossFailed(
            title: res['title'] ?? "Error",
            content: res['message'] ?? "Failed to load profit & loss report",
          ));
        }
      } catch (e) {
        emit(ProfitLossFailed(
          title: "Error",
          content: "Failed to load profit & loss report: ${e.toString()}",
        ));
      }
    });

    on<ClearProfitLossFilters>((event, emit) {
      fromDate = null;
      toDate = null;
      emit(ProfitLossInitial());
    });
  }
}