part of 'customer_bloc.dart';

// @immutable
sealed class CustomerState {}

final class CustomerInitial extends CustomerState {}

final class CustomerListLoading extends CustomerState {}

final class CustomerSuccess extends CustomerState {
  final List<CustomerModel> list;
  final int count;
  final int totalPages;
  final int currentPage;
  final int pageSize;
  final int from;
  final int to;

  CustomerSuccess({
    required this.list,
    required this.count,
    required this.totalPages,
    required this.currentPage,
    required this.pageSize,
    required this.from,
    required this.to,
  });
}

final class CustomerListFailed extends CustomerState {
  final String title, content;

  CustomerListFailed({required this.title, required this.content});
}

class CustomerToggleSpecialLoading extends CustomerState {
   CustomerToggleSpecialLoading();

  @override
  List<Object> get props => [];
}

class CustomerToggleSpecialSuccess extends CustomerState {
  final String message;

   CustomerToggleSpecialSuccess(this.message);

  @override
  List<Object> get props => [message];
}

class CustomerToggleSpecialFailed extends CustomerState {
  final String message;

   CustomerToggleSpecialFailed(this.message);

  @override
  List<Object> get props => [message];
}


final class CustomerActiveListLoading extends CustomerState {}

final class CustomerActiveSuccess extends CustomerState {
  final List<CustomerActiveModel> list;


  CustomerActiveSuccess({
    required this.list,

  });
}

final class CustomerActiveListFailed extends CustomerState {
  final String title, content;

  CustomerActiveListFailed({required this.title, required this.content});
}


final class CustomerAddInitial extends CustomerState {}

final class CustomerAddLoading extends CustomerState {}

final class CustomerAddSuccess extends CustomerState {
  CustomerAddSuccess();
}



final class CustomerDeleteLoading extends CustomerState {}

final class CustomerDeleteSuccess extends CustomerState {
  String message;
  CustomerDeleteSuccess(this.message);
}
final class CustomerAddFailed extends CustomerState {
  final String title, content;

  CustomerAddFailed({required this.title, required this.content});
}

final class CustomerSwitchInitial extends CustomerState {}

final class CustomerSwitchLoading extends CustomerState {}

final class CustomerSwitchSuccess extends CustomerState {
  CustomerSwitchSuccess();
}

final class CustomerSwitchFailed extends CustomerState {
  final String title, content;

  CustomerSwitchFailed({required this.title, required this.content});
}

sealed class CustomerDetailsState {}

final class CustomerDetailsInitial extends CustomerDetailsState {}

final class CustomerDetailsLoading extends CustomerDetailsState {}



final class CustomerDetailsFailed extends CustomerDetailsState {
  final String title, content;

  CustomerDetailsFailed({required this.title, required this.content});
}
