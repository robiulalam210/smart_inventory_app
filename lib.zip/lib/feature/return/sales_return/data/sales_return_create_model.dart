// To parse this JSON data, do
//
//     final salesReturnCreatedModel = salesReturnCreatedModelFromJson(jsonString);

import 'dart:convert';

SalesReturnCreatedModel salesReturnCreatedModelFromJson(String str) => SalesReturnCreatedModel.fromJson(json.decode(str));

String salesReturnCreatedModelToJson(SalesReturnCreatedModel data) => json.encode(data.toJson());

class SalesReturnCreatedModel {
  final bool? status;
  final String? message;
  final Data? data;

  SalesReturnCreatedModel({
    this.status,
    this.message,
    this.data,
  });

  factory SalesReturnCreatedModel.fromJson(Map<String, dynamic> json) => SalesReturnCreatedModel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  final int? id;
  final String? receiptNo;
  final dynamic customerName;
  final DateTime? returnDate;
  final dynamic accountId;
  final dynamic paymentMethod;
  final String? reason;
  final String? returnCharge;
  final dynamic returnChargeType;
  final String? returnAmount;
  final String? status;
  final List<Item>? items;

  Data({
    this.id,
    this.receiptNo,
    this.customerName,
    this.returnDate,
    this.accountId,
    this.paymentMethod,
    this.reason,
    this.returnCharge,
    this.returnChargeType,
    this.returnAmount,
    this.status,
    this.items,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    receiptNo: json["receipt_no"],
    customerName: json["customer_name"],
    returnDate: json["return_date"] == null ? null : DateTime.parse(json["return_date"]),
    accountId: json["account_id"],
    paymentMethod: json["payment_method"],
    reason: json["reason"],
    returnCharge: json["return_charge"],
    returnChargeType: json["return_charge_type"],
    returnAmount: json["return_amount"],
    status: json["status"],
    items: json["items"] == null ? [] : List<Item>.from(json["items"]!.map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "receipt_no": receiptNo,
    "customer_name": customerName,
    "return_date": "${returnDate!.year.toString().padLeft(4, '0')}-${returnDate!.month.toString().padLeft(2, '0')}-${returnDate!.day.toString().padLeft(2, '0')}",
    "account_id": accountId,
    "payment_method": paymentMethod,
    "reason": reason,
    "return_charge": returnCharge,
    "return_charge_type": returnChargeType,
    "return_amount": returnAmount,
    "status": status,
    "items": items == null ? [] : List<dynamic>.from(items!.map((x) => x.toJson())),
  };
}

class Item {
  final int? id;
  final String? productName;
  final int? quantity;
  final int? damageQuantity;
  final String? unitPrice;
  final String? discount;
  final dynamic discountType;
  final String? total;

  Item({
    this.id,
    this.productName,
    this.quantity,
    this.damageQuantity,
    this.unitPrice,
    this.discount,
    this.discountType,
    this.total,
  });

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    productName: json["product_name"],
    quantity: json["quantity"],
    damageQuantity: json["damage_quantity"],
    unitPrice: json["unit_price"],
    discount: json["discount"],
    discountType: json["discount_type"],
    total: json["total"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_name": productName,
    "quantity": quantity,
    "damage_quantity": damageQuantity,
    "unit_price": unitPrice,
    "discount": discount,
    "discount_type": discountType,
    "total": total,
  };
}
