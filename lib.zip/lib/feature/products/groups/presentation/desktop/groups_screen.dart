import 'package:flutter/material.dart';
import 'package:meherinMart/core/widgets/app_popover_route.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lottie/lottie.dart';
import 'package:meherinMart/core/configs/app_sizes.dart';
import '/feature/products/groups/presentation/shared/create_groups.dart';
import '../../../../../core/configs/app_colors.dart';
import '../../../../../core/configs/app_images.dart';
import '../../../../../core/configs/app_routes.dart';
import '../../../../../core/configs/app_text.dart';
import '../../../../../core/configs/gaps.dart';
import '../../../../../desktop/widgets/sidebar.dart';
import '../../../../../core/widgets/app_alert_dialog.dart';
import '../../../../../core/widgets/app_button.dart';
import '../../../../../core/widgets/app_loader.dart';
import '../../../../../core/widgets/coustom_search_text_field.dart';
import '../../../../../core/widgets/show_custom_toast.dart';
import '../../../../../responsive.dart';
import '../bloc/groups/groups_bloc.dart';
import '../widget/widget.dart';

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  // Add a ScrollController
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _fetchApi();
  }

  @override
  void dispose() {
    // Dispose the scroll controller
    _scrollController.dispose();
    super.dispose();
  }

  void _fetchApi({String filterText = '', int pageNumber = 0}) {
    context.read<GroupsBloc>().add(
      FetchGroupsList(
        context,
        filterText: filterText,
        state: context.read<GroupsBloc>().selectedState == "All"
            ? ""
            : context.read<GroupsBloc>().selectedState,
        pageNumber: pageNumber,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isBigScreen =
        Responsive.isDesktop(context) || Responsive.isMaxDesktop(context);
    final isMobile = Responsive.isMobile(context);

    return Container(
      color: AppColors.bottomNavBg(context),
      child: SafeArea(
        child: ResponsiveRow(
          spacing: 0,
          runSpacing: 0,
          children: [
            if (isBigScreen) _buildSidebar(),
            _buildContentArea(isBigScreen, isMobile),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebar() {
    return ResponsiveCol(
      xs: 0,
      sm: 1,
      md: 1,
      lg: 2,
      xl: 2,
      child: Container(
        decoration: const BoxDecoration(color: Colors.white),
        child: const Sidebar(),
      ),
    );
  }

  Widget _buildContentArea(bool isBigScreen, bool isMobile) {
    return ResponsiveCol(
      xs: 12,
      sm: 12,
      md: 12,
      lg: 10,
      xl: 10,
      child: Container(
        color: AppColors.bottomNavBg(context),
        child: buildContent(isMobile),
      ),
    );
  }

  Widget buildContent(bool isMobile) {
    return BlocListener<GroupsBloc, GroupsState>(
      listener: (context, state) {
        if (state is GroupsAddLoading) {
          appLoader(context, "Creating Group, please wait...");
        } else if (state is GroupsSwitchLoading) {
          appLoader(context, "Update Group, please wait...");
        } else if (state is GroupDeleteLoading) {
          appLoader(context, "Deleted Group, please wait...");
        } else if (state is GroupsAddSuccess) {
          Navigator.pop(context);
          Navigator.pop(context);
          _fetchApi();
        } else if (state is GroupsSwitchSuccess) {
          Navigator.pop(context);
          _fetchApi();
        } else if (state is GroupDeleteSuccess) {
          showCustomToast(
            context: context,
            title: 'Success!',
            description: state.message,
            icon: Icons.check_circle,
            primaryColor: AppColors.success,
          );
          Navigator.pop(context);
          _fetchApi();
        } else if (state is GroupsAddFailed) {
          Navigator.pop(context);
          Navigator.pop(context);
          _fetchApi();
          appAlertDialog(
            context,
            state.content,
            title: state.title,
            actions: [
              TextButton(
                onPressed: () => AppRoutes.pop(context),
                child: const Text("Dismiss"),
              ),
            ],
          );
        } else if (state is GroupDeleteFailed) {
          Navigator.pop(context);
          _fetchApi();
          appAlertDialog(
            context,
            state.content,
            title: state.title,
            actions: [
              TextButton(
                onPressed: () => AppRoutes.pop(context),
                child: const Text("Dismiss"),
              ),
            ],
          );
        }
      },
      child: RefreshIndicator(
        // Use the controller for RefreshIndicator
        onRefresh: () async {
          _fetchApi();
        },
        child: SingleChildScrollView(
          // Pass the controller to SingleChildScrollView
          controller: _scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Container(
            padding: isMobile
                ? const EdgeInsets.all(12)
                : AppTextStyle.getResponsivePaddingBody(context),
            child: Column(
              children: [
                // Header Row
                _buildHeaderRow(isMobile),
                gapH16,
                // Groups List
                _buildGroupsList(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderRow(bool isMobile) {
    if (isMobile) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Search Field
          CustomSearchTextFormField(
            controller: context.read<GroupsBloc>().filterTextController,
            onChanged: (value) {
              _fetchApi(filterText: value);
            },
            isRequiredLabel: false,
            hintText: "Search group name",
          ),
          const SizedBox(height: 12),
          // Create Button
          SizedBox(
            width: double.infinity,
            child: AppButton(
              name: "Create Group",
              onPressed: () => _showCreateDialog(context),
            ),
          ),
        ],
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 350,
          child: CustomSearchTextFormField(
            controller: context.read<GroupsBloc>().filterTextController,
            onChanged: (value) {
              _fetchApi(filterText: value);
            },
            isRequiredLabel: false,
            hintText: "Search group name",
          ),
        ),
        gapW16,
        AppButton(
          name: "Create Group",
          onPressed: () => _showCreateDialog(context),
        ),
      ],
    );
  }

  Widget _buildGroupsList() {
    return BlocBuilder<GroupsBloc, GroupsState>(
      builder: (context, state) {
        if (state is GroupsListLoading) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(),
            ),
          );
        } else if (state is GroupsListSuccess) {
          if (state.list.isEmpty) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: Lottie.asset(AppImages.noData),
              ),
            );
          } else {
            return GroupsTableCard(
              groups: state.list,
              onGroupTap: () {},
            );
          }
        } else if (state is GroupsListFailed) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Failed to load groups: ${state.content}'),
            ),
          );
        } else {
          return Container();
        }
      },
    );
  }

  void _showCreateDialog(BuildContext context) {
    showAppPopover(
      context: context,
      builder: (context) {
        return AppPopoverShell(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSizes.radius),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppSizes.radius),
            child: SizedBox(
              width: Responsive.isMobile(context)
                  ? MediaQuery.of(context).size.width * 0.9
                  : MediaQuery.of(context).size.width * 0.5,
              child: const GroupsCreate(),
            ),
          ),
        );
      },
    );
  }
}