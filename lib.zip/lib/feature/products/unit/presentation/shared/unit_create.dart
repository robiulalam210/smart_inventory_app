import '/feature/products/unit/presentation/bloc/unit/unti_bloc.dart';
import '../../../../../core/configs/configs.dart';
import '../../../../../core/widgets/app_button.dart';
import '../../../../../core/widgets/app_dropdown.dart';
import '../../../../../core/widgets/input_field.dart';
import '../../../../../core/widgets/show_custom_toast.dart';

class UnitCreate extends StatefulWidget {
  final String? id;

  const UnitCreate({super.key, this.id});

  @override
  State<UnitCreate> createState() => _UnitCreateState();
}

class _UnitCreateState extends State<UnitCreate> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  void _showConfirmationDialog() {
    showAppPopover(
      context: context,
      builder: (BuildContext context) {
        return AppPopoverCard(
          title: Text('Confirm', style: AppTextStyle.titleMedium(context)),
          content: Text(
            widget.id == null
                ? 'Are you sure you want to create this unit?'
                : 'Are you sure you want to update this unit?',
            style: AppTextStyle.body(context),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _submitForm();
              },
              child: const Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  void _submitForm() {
    if (formKey.currentState!.validate()) {
      final Map<String, dynamic> body = {
        "name": context.read<UnitBloc>().nameController.text.trim(),
        "code": context.read<UnitBloc>().shortNameController.text.trim(),
      };
      if (widget.id != null &&
          context.read<UnitBloc>().selectedState.trim().isNotEmpty) {
        body["is_active"] = context.read<UnitBloc>().selectedState == "Active"
            ? true
            : false;
      }
      if (widget.id == null) {
        // Create new unit
        context.read<UnitBloc>().add(AddUnit(body: body));
      } else {
        // Update existing unit
        context.read<UnitBloc>().add(UpdateUnit(body: body, id: widget.id!));
      }
    }
  }

  void _clearForm() {
    context.read<UnitBloc>().nameController.clear();
    formKey.currentState?.reset();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<UnitBloc, UnitState>(
      listener: (context, state) {
        if (state is UnitAddSuccess) {
          showCustomToast(
            context: context,
            title: 'Success!',
            description: widget.id == null
                ? 'Unit created successfully!'
                : 'Unit updated successfully!',
            type: ToastificationType.success,
            icon: Icons.check_circle,
            primaryColor: AppColors.success,
          );

          // Clear form and close on success
          if (widget.id == null) {
            _clearForm();
          }
          // Navigator.pop(context, true); // Return success result
        } else if (state is UnitAddFailed) {
          showCustomToast(
            context: context,
            title: state.title,
            description: state.content,
            type: ToastificationType.error,
            icon: Icons.error,
            primaryColor: Colors.redAccent,
          );
        }
      },
      child: _buildDialogContent(),
    );
  }

  Widget _buildDialogContent() {
    return Container(
      color: AppColors.bottomNavBg(context),
      // width: AppSizes.width(context) * 0.40,
      padding: const EdgeInsets.all(20),
      child: Form(
        key: formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with close button and title
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.id == null ? 'Create Unit' : 'Update Unit',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryColor(context),
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(Icons.close, color: AppColors.danger, size: 20),
                  padding: EdgeInsets.zero,
                  constraints: BoxConstraints(),
                ),
              ],
            ),

            SizedBox(height: 10),

            // Name Input Field
            CustomInputField(
              isRequiredLable: true,
              isRequired: true,
              controller: context.read<UnitBloc>().nameController,
              hintText: 'Enter unit name (e.g., Kilogram)',
              labelText: 'Unit Name',
              fillColor: Colors.grey[50],
              keyboardType: TextInputType.text,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter unit name';
                }
                if (value.length < 2) {
                  return 'Unit name must be at least 2 characters long';
                }
                if (value.length > 50) {
                  return 'Unit name must be less than 50 characters';
                }
                return null;
              },
            ),

            SizedBox(height: 16),

            // Short Name/Code Input Field
            CustomInputField(
              isRequiredLable: true,
              isRequired: true,
              controller: context.read<UnitBloc>().shortNameController,
              hintText: 'Enter unit code (e.g., kg)',
              labelText: 'Unit Code',
              fillColor: Colors.grey[50],
              keyboardType: TextInputType.text,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter unit code';
                }
                if (value.isEmpty) {
                  return 'Unit code must be at least 1 character long';
                }
                if (value.length > 10) {
                  return 'Unit code must be less than 10 characters';
                }
                // Optional: Add regex validation for codes
                if (!RegExp(r'^[a-zA-Z0-9]+$').hasMatch(value)) {
                  return 'Unit code can only contain letters and numbers';
                }
                return null;
              },
            ),

            SizedBox(height: 10),
            if (widget.id != null) ...[
              LayoutBuilder(
                builder: (context, constraints) {
                  final isSmallScreen = constraints.maxWidth < 600;

                  return SizedBox(
                    width: isSmallScreen
                        ? double.infinity
                        : constraints.maxWidth * 0.5,
                    child: AppDropdown(
                      label: "Status",
                      hint: "Select Status",
                      isLabel: false,
                      value: context.read<UnitBloc>().selectedState.isEmpty
                          ? null
                          : context.read<UnitBloc>().selectedState,
                      itemList: ["Active", "Inactive"],
                      onChanged: (newVal) {
                        setState(() {
                          context.read<UnitBloc>().selectedState = newVal
                              .toString();
                        });
                      },
                    ),
                  );
                },
              ),
              SizedBox(height: AppSizes.height(context) * 0.01),
            ],

            // Buttons Row
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AppButton(
                  isOutlined: true,
                  size: 120,
                  color: AppColors.primaryColor(context),
                  borderColor: AppColors.primaryColor(context),
                  textColor: AppColors.errorColor(context),
                  name: 'Cancel',
                  onPressed: () => Navigator.pop(context),
                ),
                SizedBox(width: 10),
                BlocBuilder<UnitBloc, UnitState>(
                  builder: (context, state) {
                    return AppButton(
                      size: 120,
                      name: widget.id == null ? 'Create' : 'Update',
                      onPressed: (state is UnitAddLoading)
                          ? null
                          : _showConfirmationDialog,
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
