part of 'products_bloc.dart';

sealed class ProductsState {}

final class ProductsInitial extends ProductsState {}




final class ProductsListLoading extends ProductsState {}

class ProductsListSuccess extends ProductsState {
  final List<ProductModel> list;
  final int totalPages;
  final int currentPage; // 1-based
  final int count; // total items
  final int pageSize;
  final int from;
  final int to;

   ProductsListSuccess({
    required this.list,
    required this.totalPages,
    required this.currentPage,
    required this.count,
    required this.pageSize,
    required this.from,
    required this.to,
  });

  List<Object?> get props => [list, totalPages, currentPage, count, pageSize, from, to];
}
class ProductsListStockSuccess extends ProductsState {
  final List<ProductModelStockModel> list;


  ProductsListStockSuccess({
    required this.list,

  });


}
final class ProductsListFailed extends ProductsState {
  final String title, content;

  ProductsListFailed({required this.title, required this.content});
}



final class ProductsAddInitial extends ProductsState {}

final class ProductsAddLoading extends ProductsState {}

final class ProductsAddSuccess extends ProductsState {
  ProductsAddSuccess();
}



final class ProductsDeleteFailed extends ProductsState {
  final String title, content;

  ProductsDeleteFailed({required this.title, required this.content});
}

final class ProductsDeleteInitial extends ProductsState {}

final class ProductsDeleteLoading extends ProductsState {}

final class ProductsDeleteSuccess extends ProductsState {
  String message;
  ProductsDeleteSuccess(this.message);
}



final class ProductsAddFailed extends ProductsState {
  final String title, content;

  ProductsAddFailed({required this.title, required this.content});
}






