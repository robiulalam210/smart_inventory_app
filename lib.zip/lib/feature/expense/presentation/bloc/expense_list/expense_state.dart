part of 'expense_bloc.dart';

// @immutable
sealed class ExpenseState {}

final class ExpenseInitial extends ExpenseState {}


final class ExpenseListLoading extends ExpenseState {}
final class ExpenseListSuccess extends ExpenseState {
  final List<ExpenseModel> list;
  final int totalPages;
  final int currentPage;
  final int count;
  final int pageSize;
  final int from;
  final int to;

  ExpenseListSuccess({
    required this.list,
    required this.totalPages,
    required this.currentPage,
    required this.count,
    required this.pageSize,
    required this.from,
    required this.to,
  });

  List<Object?> get props => [
    list,
    totalPages,
    currentPage,
    count,
    pageSize,
    from,
    to,
  ];
}



final class ExpenseListFailed extends ExpenseState {
  final String title, content;

  ExpenseListFailed({required this.title, required this.content});
}





final class ExpenseAddLoading extends ExpenseState {}

final class ExpenseAddSuccess extends ExpenseState {
  ExpenseAddSuccess();
}



final class ExpenseAddFailed extends ExpenseState {
  final String title, content;

  ExpenseAddFailed({required this.title, required this.content});
}


final class ExpenseDeleteLoading extends ExpenseState {}

final class ExpenseDeleteSuccess extends ExpenseState {
  ExpenseDeleteSuccess();
}



final class ExpenseDeleteFailed extends ExpenseState {
  final String title, content;

  ExpenseDeleteFailed({required this.title, required this.content});
}

