import 'package:meherinMart/feature/auth/presentation/mobile/mobile_login_scr.dart';
import 'package:meherinMart/feature/audit_log/presentation/audit_log_screen.dart';
import 'package:meherinMart/feature/users_list/presentation/shared/mobile_user_permissions_screen.dart';
import 'package:meherinMart/feature/payroll/presentation/mobile_advances_screen.dart';
import 'package:meherinMart/feature/payroll/presentation/mobile_payroll_report_screen.dart';
import 'package:meherinMart/feature/payroll/presentation/mobile_salary_sheet_screen.dart';
import 'package:meherinMart/feature/expense/expense_head/presentation/mobile/mobile_expense_head_screen.dart';
import 'package:meherinMart/feature/expense/expense_sub_head/presentation/mobile/mobile_expense_sub_head_screen.dart';
import 'package:meherinMart/feature/expense/presentation/mobile/mobile_expense_list_screen.dart';
import 'package:meherinMart/feature/income/income_expense/presentation/shared/income_expense_head_page.dart';
import 'package:meherinMart/feature/income/presentation/shared/income_page_list.dart';
import 'package:meherinMart/feature/products/brand/presentation/mobile/mobile_brand_screen.dart';
import 'package:meherinMart/feature/products/categories/presentation/mobile/mobile_categories_screen.dart';
import 'package:meherinMart/feature/products/groups/presentation/mobile/mobile_groups_screen.dart';
import 'package:meherinMart/feature/products/soruce/presentation/mobile/mobile_source_screen.dart';
import 'package:meherinMart/feature/products/unit/presentation/mobile/mobile_unit_screen.dart';
import 'package:meherinMart/feature/profile/presentation/bloc/profile_bloc/profile_bloc.dart';
import 'package:meherinMart/feature/sales/presentation/mobile/mobile_pos_sale_screen.dart';

import '../../feature/account_transfer/presentation/mobile/mobile_account_transfer_form.dart';
import '../../feature/account_transfer/presentation/mobile/mobile_account_transfer_screen.dart';
import '../../feature/accounts/presentation/mobile/mobile_account_screen.dart';
import '../../feature/customer/presentation/mobile/mobile_customer_screen.dart';
import '../../feature/lab_dashboard/presentation/bloc/dashboard/dashboard_bloc.dart';
import '../../feature/money_receipt/presentation/mobile/mobile_monery_receipt_create.dart';
import '../../feature/money_receipt/presentation/mobile/mobile_money_receipt_list.dart';
import '../../feature/products/product/presentation/mobile/mobile_product_screen.dart';
import '../../feature/products/sale_mode/presentation/shared/sale_mode_list_screen.dart';
import '../../feature/profile/data/model/profile_perrmission_model.dart';
import '../../feature/profile/presentation/mobile/moble_profile_screen.dart';
import '../../feature/purchase/presentation/mobile/mobile_create_purchase_screen.dart';
import '../../feature/purchase/presentation/mobile/mobile_purchase_screen.dart';
import '../../feature/report/presentation/mobile/customer_due_advance_screen/mobile_customer_due_advance_screen.dart';
import '../../feature/report/presentation/mobile/customer_ledger_screen/mobile_customer_ledger_screen.dart';
import '../../feature/report/presentation/mobile/expense_report_screen/mobile_expense_report_screen.dart';
import '../../feature/report/presentation/mobile/low_stock_screen/mobile_low_stock_screen.dart';
import '../../feature/report/presentation/mobile/profit_loss_screen/mobile_profit_loss_screen.dart';
import '../../feature/report/presentation/mobile/purchase_report_screen/mobile_purchase_report_screen.dart';
import '../../feature/report/presentation/mobile/sales_report_page/mobile_sales_report_screen.dart';
import '../../feature/report/presentation/mobile/stock_report_screen/mobile_stock_report_screen.dart';
import '../../feature/report/presentation/mobile/supplier_due_advance_screen/mobile_supplier_due_advance_screen.dart';
import '../../feature/report/presentation/mobile/supplier_ledger_screen/mobile_supplier_ledger_screen.dart';
import '../../feature/report/presentation/mobile/top_products_screen/mobile_top_products_screen.dart';
import '../../feature/return/bad_stock/mobile/mobile_bad_stock_screen.dart';
import '../../feature/return/purchase_return/presentation/purchase_return/mobile/mobile_purchase_return_screen.dart';
import '../../feature/return/sales_return/presentation/mobile/mobile_sales_return_page.dart';
import '../../feature/sales/presentation/mobile/create_pos_sale/mobile_create_pos_sale.dart';
import '../../feature/sales/presentation/mobile/create_pos_sale/mobile_create_sales_pos.dart';
import '../../feature/sales/presentation/mobile/create_pos_sale/mobile_short_create_pos_sale.dart';
import '../../feature/supplier/presentation/mobile/mobile_supplier_list_screen.dart';
import '../../feature/supplier/presentation/mobile/mobile_supplier_payment_list_screen.dart';
import '../../feature/transactions/presentation/mobile/mobile_transaction_screen.dart';
import '../../feature/users_list/presentation/shared/moblie_users_screen.dart';
import '../../core/configs/configs.dart';
import '../../core/shared/widgets/sideMenu/menu_tile.dart';

class MobileTabSidebar extends StatelessWidget {
  const MobileTabSidebar({super.key});

  // Same menu structure as Sidebar for consistency
  List<MenuSection> getMenuSections(Permissions? permissions, {String? role}) {
    final sections = <MenuSection>[];

    // Dashboard Section
    if (permissions?.dashboard?.view == true) {
      sections.add(
        MenuSection(
          title: "My Dashboard",
          items: [MenuItem(title: "My Dashboard", index: 0)],
        ),
      );
    }

    // Sales Section
    if (permissions?.sales?.view == true) {
      sections.add(
        MenuSection(
          title: "Sales",
          items: [
            if (permissions?.sales?.create == true)
              MenuItem(title: "Sale", index: 1),
            if (permissions?.sales?.create == true)
              MenuItem(title: "POS Sale", index: 2),
            if (permissions?.sales?.create == true)
              MenuItem(title: "Short Sale", index: 3),
            if (permissions?.sales?.view == true)
              MenuItem(title: "Sale List", index: 4),
          ],
        ),
      );
    }

    // Money Receipt Section
    if (permissions?.moneyReceipt?.view == true) {
      sections.add(
        MenuSection(
          title: "Money Receipt",
          items: [
            if (permissions?.moneyReceipt?.create == true)
              MenuItem(title: "Create Money Receipt", index: 5),
            if (permissions?.moneyReceipt?.view == true)
              MenuItem(title: "Money Receipt List", index: 6),
          ],
        ),
      );
    }

    // Purchase Section
    if (permissions?.purchases?.view == true) {
      sections.add(
        MenuSection(
          title: "Purchase",
          items: [
            if (permissions?.purchases?.create == true)
              MenuItem(title: "Create Purchase", index: 7),
            if (permissions?.purchases?.view == true)
              MenuItem(title: "Purchase List", index: 8),
          ],
        ),
      );
    }

    // Products Section
    if (permissions?.products?.view == true) {
      sections.add(
        MenuSection(
          title: "Products",
          items: [MenuItem(title: "Products", index: 9)],
        ),
      );
    }

    // Accounts Section
    if (permissions?.accounts?.view == true) {
      sections.add(
        MenuSection(
          title: "Accounts",
          items: [MenuItem(title: "Accounts", index: 10)],
        ),
      );
    }

    // Customers Section
    if (permissions?.customers?.view == true) {
      sections.add(
        MenuSection(
          title: "Customers",
          items: [MenuItem(title: "Customers", index: 11)],
        ),
      );
    }

    // Supplier Section
    if (permissions?.suppliers?.view == true) {
      sections.add(
        MenuSection(
          title: "Supplier",
          items: [
            if (permissions?.suppliers?.view == true)
              MenuItem(title: "Supplier List", index: 12),
            if (permissions?.suppliers?.view == true)
              MenuItem(title: "Supplier Payment", index: 13),
          ],
        ),
      );
    }

    // Expense Section
    if (permissions?.expense?.view == true) {
      sections.add(
        MenuSection(
          title: "Expense",
          items: [
            if (permissions?.expense?.view == true)
              MenuItem(title: "Expense List", index: 14),
            if (permissions?.expense?.view == true)
              MenuItem(title: "Expense Head", index: 15),
            if (permissions?.expense?.view == true)
              MenuItem(title: "Expense Sub Head", index: 16),
          ],
        ),
      );
    }

    // Return Section
    if (permissions?.permissionsReturn?.view == true) {
      sections.add(
        MenuSection(
          title: "Return",
          items: [
            if (permissions?.permissionsReturn?.view == true)
              MenuItem(title: "Sales Return", index: 19),
            if (permissions?.permissionsReturn?.view == true)
              MenuItem(title: "Bad Stock List", index: 20),
            if (permissions?.permissionsReturn?.view == true)
              MenuItem(title: "Purchase Return", index: 21),
          ],
        ),
      );
    }

    // Reports Section
    if (permissions?.reports?.view == true) {
      sections.add(
        MenuSection(
          title: "Reports",
          items: [
            if (permissions?.reports?.view == true)
              MenuItem(title: "Sales Report", index: 22),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Purchase Report", index: 23),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Profit / Loss", index: 24),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Top Selling Products", index: 25),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Low Stock", index: 26),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Stock Report", index: 27),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Customer Ledger", index: 28),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Customer Due / Advance", index: 29),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Supplier Ledger", index: 30),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Supplier Due / Advance", index: 31),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Expense Report", index: 32),
            if (permissions?.reports?.view == true)
              MenuItem(title: "Bad Stock Report", index: 33),
          ],
        ),
      );
    }

    // Administration Section
    if (permissions?.administration?.view == true) {
      sections.add(
        MenuSection(
          title: "Administration",
          items: [
            if (permissions?.users?.view == true)
              MenuItem(title: "Staff", index: 34),
            MenuItem(title: "Source", index: 35),
            MenuItem(title: "Unit", index: 36),
            MenuItem(title: "Brand", index: 37),
            MenuItem(title: "Category", index: 38),
            MenuItem(title: "Group", index: 39),
            MenuItem(title: "Sale Mode", index: 40),
            MenuItem(title: "Profile", index: 41),
          ],
        ),
      );
    }

    // Income Section — ওয়েবের মতো Administration এর পরে, permission = accounts.view
    if (permissions?.accounts?.view == true) {
      sections.add(
        MenuSection(
          title: "Income",
          items: [
            MenuItem(title: "Income List", index: 17),
            MenuItem(title: "Income Head", index: 18),
          ],
        ),
      );
    }

    // Transfer Balance Section (assuming it's under accounts)
    if (permissions?.accounts?.view == true) {
      sections.add(
        MenuSection(
          title: "Transfer Balance",
          items: [
            MenuItem(title: "Account Transfer", index: 42),
            MenuItem(title: "Transfer List", index: 43),
            MenuItem(title: "Transactions", index: 44),
          ],
        ),
      );
    }

    // Payroll Section — ওয়েবের মতো শুধু Super Admin / Admin
    final roleUp = role?.toUpperCase();
    if (roleUp == 'SUPER_ADMIN' || roleUp == 'ADMIN') {
      sections.add(
        MenuSection(
          title: "Payroll",
          items: [
            MenuItem(title: "Salary Sheet", index: 46),
            MenuItem(title: "Advances", index: 47),
            MenuItem(title: "Payroll Report", index: 48),
          ],
        ),
      );
    }

    // Audit Log — module permission নয়, role দেখে (শুধু Super Admin / Admin)
    final r = role?.toUpperCase();
    if (r == 'SUPER_ADMIN' || r == 'ADMIN') {
      sections.add(
        MenuSection(
          title: "Security",
          items: [
            MenuItem(title: "Audit Log", index: 45),
            MenuItem(title: "User Permissions", index: 49),
          ],
        ),
      );
    }

    return sections;
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppColors.bottomNavBg(context),
      child: SafeArea(
        child: BlocBuilder<DashboardBloc, DashboardState>(
          builder: (context, state) {
            int currentIndex = 0;

            if (state is DashboardScreenChanged) {
              currentIndex = state.index;
            }

            final permission = context
                .read<ProfileBloc>()
                .permissionModel
                ?.data
                ?.permissions;

            // Get dynamic menu sections based on permissions
            final role = context.read<ProfileBloc>().permissionModel?.data?.user?.role;
            final menuSections = getMenuSections(permission, role: role);

            // Show empty state if no permissions
            if (menuSections.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.lock_outline, size: 64, color: Colors.grey[400]),
                    const SizedBox(height: 16),
                    Text(
                      "No Menu Access",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Contact administrator for access",
                      style: TextStyle(color: Colors.grey[500]),
                    ),
                  ],
                ),
              );
            }

            return Column(
              children: [
                /// Drawer Header — লোগো + ব্যবসার নাম
                Builder(builder: (context) {
                  final primary = AppColors.primaryColor(context);
                  final onPrimary = AppColors.onColor(primary);
                  final businessName = context
                      .read<ProfileBloc>()
                      .permissionModel
                      ?.data
                      ?.businessInfo
                      ?.name;
                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient(context),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Image.asset(
                            "assets/images/logo.png",
                            fit: BoxFit.contain,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                Icons.storefront_rounded,
                                color: primary,
                                size: 28,
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                (businessName == null || businessName.isEmpty)
                                    ? AppConstants.appName
                                    : businessName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: onPrimary,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Inventory & POS',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: onPrimary.withValues(alpha: 0.8),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }),

                const Divider(height: 1),

                /// Menu Content
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSizes.paddingInside,
                      vertical: 8,
                    ),
                    children: [
                      // Build all menu sections dynamically
                      ...menuSections.map((section) {
                        if (section.items.isEmpty) {
                          return const SizedBox.shrink();
                        }

                        if (section.items.length == 1) {
                          // Single item (no expansion)
                          final item = section.items.first;
                          return MobileMenuTile(
                            isSubmenu: true,
                            title: section.title,
                            isSelected: currentIndex == item.index,
                            onPressed: () {
                              _handleMenuSelection(
                                item.index,
                                context,
                                permission,
                              );
                            },
                          );
                        } else {
                          // Multiple items (with expansion)
                          return Theme(
                            data: Theme.of(context).copyWith(
                              dividerColor: Colors.transparent,
                            ),
                            child: ExpansionTile(
                            initiallyExpanded: section.items.any(
                              (item) => currentIndex == item.index,
                            ),
                            title: Text(
                              section.title,
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                                color: AppColors.text(context),
                              ),
                            ),
                            children: section.items.map((item) {
                              return MobileMenuTile(
                                isSubmenu: true,
                                title: item.title,
                                isSelected: currentIndex == item.index,
                                onPressed: () {
                                  _handleMenuSelection(
                                    item.index,
                                    context,
                                    permission,
                                  );
                                },
                              );
                            }).toList(),
                            ),
                          );
                        }
                      }),
                    ],
                  ),
                ),

                /// Logout Button
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSizes.paddingInside,
                    vertical: AppSizes.paddingInside,
                  ),
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(46),
                      elevation: 0,
                      backgroundColor: AppColors.danger.withValues(alpha: 0.10),
                      foregroundColor: AppColors.danger,
                      side: BorderSide(
                        color: AppColors.danger.withValues(alpha: 0.35),
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.logout, size: 18),
                    label: const Text(
                      "Logout",
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                    onPressed: () {
                      _handleLogout(context);
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _handleMenuSelection(
    int index,
    BuildContext context,
    Permissions? permissions,
  ) {
    // Check permissions before navigation
    switch (index) {
      case 0: // Dashboard
        if (permissions?.dashboard?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.pop(context);
        break;

      case 1: // Sale (Create)
        if (permissions?.sales?.create != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCreatePosSale());
        break;

      case 2: // Pos Sale
        if (permissions?.sales?.create != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSalesScreen());
        break;

      case 3: // Short Sale
        if (permissions?.sales?.create != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileShortCreatePosSale());
        break;

      case 4: // Sale List
        if (permissions?.sales?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobilePosSaleScreen());
        break;

      case 5: // Create Money Receipt
        if (permissions?.moneyReceipt?.create != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileMoneyReceiptForm());
        break;

      case 6: // Money Receipt List
        if (permissions?.moneyReceipt?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileMoneyReceiptList());
        break;

      case 7: // Create Purchase
        if (permissions?.purchases?.create != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCreatePurchaseScreen());
        break;

      case 8: // Purchase List
        if (permissions?.purchases?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobilePurchaseScreen());
        break;

      case 9: // Product
        if (permissions?.products?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileProductScreen());
        break;

      case 10: // Accounts
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileAccountScreen());
        break;

      case 11: // Customer
        if (permissions?.customers?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCustomerScreen());
        break;

      case 12: // Supplier List
        if (permissions?.suppliers?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSupplierListScreen());
        break;

      case 13: // Supplier Payment
        if (permissions?.suppliers?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSupplierPaymentListScreen());
        break;

      case 14: // Expense List
        if (permissions?.expense?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileExpenseListScreen());
        break;

      case 15: // Expense Head
        if (permissions?.expense?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileExpenseHeadScreen());
        break;

      case 16: // Expense Sub Head
        if (permissions?.expense?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileExpenseSubHeadScreen());
        break;

      case 17: // Income List
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileIncomeListScreen());
        break;

      case 18: // Income Head
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileIncomeHeadScreen());
        break;



      case 19: // Sales Return
        if (permissions?.permissionsReturn?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSalesReturnPage());
        break;

      case 20: // Bad Stock List
        if (permissions?.permissionsReturn?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileBadStockScreen());
        break;

      case 21: // Purchase Return
        if (permissions?.permissionsReturn?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobilePurchaseReturnScreen());
        break;

      case 22: // Sales Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSalesReportScreen());
        break;

      case 23: // Purchase Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobilePurchaseReportScreen());
        break;

      case 24: // Profit/Loss Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileProfitLossScreen());
        break;

      case 25: // Top Sale Product Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileTopProductsScreen());
        break;

      case 26: // Low Stock Product Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileLowStockScreen());
        break;

      case 27: // Stock Product Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileStockReportScreen());
        break;

      case 28: // Customer Ledger
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCustomerLedgerScreen());
        break;

      case 29: // Customer Due/Advance Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCustomerDueAdvanceScreen());
        break;

      case 30: // Supplier Ledger
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSupplierLedgerScreen());
        break;

      case 31: // Supplier Due/Advance Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSupplierDueAdvanceScreen());
        break;

      case 32: // Expense Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileExpenseReportScreen());
        break;

      case 33: // Bad Stock Report
        if (permissions?.reports?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileBadStockScreen());
        break;

      case 34: // Staff
        if (permissions?.users?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MoblieUsersScreen());
        break;

      case 35: // Source
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileSourceScreen());
        break;

      case 36: // Unit
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileUnitScreen());
        break;

      case 37: // Brand
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileBrandScreen());
        break;

      case 38: // Category
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileCategoriesScreen());
        break;

      case 39: // Group
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileGroupsScreen());
        break;

      case 40: // Sale Mode
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, SaleModeListScreen());
        break;


      case 41: // Profile
        if (permissions?.administration?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileProfileScreen());
        break;

      case 42: // Account Transfer From
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileAccountTransferForm());
        break;

      case 43: // Account Transfer List
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileAccountTransferScreen());
        break;

      case 44: // Transactions
        if (permissions?.accounts?.view != true) {
          _showPermissionDeniedDialog(context);
          return;
        }
        AppRoutes.push(context, MobileTransactionScreen());
        break;

      case 45: // Audit Log — getMenuSections এ শুধু Super Admin / Admin এর জন্য যোগ হয়
        AppRoutes.push(context, const AuditLogScreen());
        break;

      case 46: // Salary Sheet
        AppRoutes.push(context, const MobileSalarySheetScreen());
        break;

      case 47: // Advances
        AppRoutes.push(context, const MobileAdvancesScreen());
        break;

      case 48: // Payroll Report
        AppRoutes.push(context, const MobilePayrollReportScreen());
        break;

      case 49: // User Permissions — getMenuSections এ শুধু Super Admin / Admin এর জন্য যোগ হয়
        AppRoutes.push(context, const MobileUserPermissionsScreen());
        break;

      default:
        // Fallback: do nothing or show a snack bar
        break;
    }
  }

  void _showPermissionDeniedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Access Denied"),
          content: const Text(
            "You don't have permission to access this feature.",
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  void _handleLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Logout"),
          content: const Text("Are you sure you want to logout?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
                LocalDB.delLoginInfo();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => MobileLoginScr()),
                  (route) => false,
                );
              },
              child: const Text("Logout", style: TextStyle(color: AppColors.danger)),
            ),
          ],
        );
      },
    );
  }
}

// Helper classes for menu structure
class MenuSection {
  final String title;
  final List<MenuItem> items;
  final bool Function(Permissions? permissions)? requiredPermission;

  MenuSection({
    required this.title,
    required this.items,
    this.requiredPermission,
  });
}

class MenuItem {
  final String title;
  final int index;
  final bool Function(Permissions? permissions)? requiredPermission;

  MenuItem({required this.title, required this.index, this.requiredPermission});
}
